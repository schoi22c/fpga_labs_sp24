/**
 * mmmm.c
 *
 * Basic Matrix Multiplication Loop Code
 **/
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <math.h>
#include <sys/time.h>

#define SIZE (1 << 10)
//#define SIZE (1<<12)

double A[SIZE][SIZE];
double B[SIZE][SIZE];
double C[SIZE][SIZE];

#define EPSILON (0.000001)

/*
 * The below very neat implementation of float eqaul is taken from
 * http://floating-point-gui.de/errors/comparison/
 *
 * Published at floating-point-gui.de under the Creative Commons
 * Attribution License (BY)
 * http://creativecommons.org/licenses/by/3.0/
 */
int nearlyEqual(double a, double b) {
  double absA = fabs(a);
  double absB = fabs(b);
  double diff = fabs(a - b);

  if (a == b) { // shortcut, handles infinities
    return 1;
  } else if (a == 0 || b == 0 || diff < FLT_MIN) {
    // a or b is zero or both are extremely close to it
    // relative error is less meaningful here
    return diff < (EPSILON * FLT_MIN);
  } else { // use relative error
    return diff / fmin((absA + absB), FLT_MAX) < EPSILON;
  }
}

/*
 * Performs matrix-matrix multiplication of A and B, storing the
 * result in the matrix C. Assumes C is initiazlied to 0.
 */
void mmmm(double A[SIZE][SIZE], double B[SIZE][SIZE], double C[SIZE][SIZE]) {

  for (int i = 0; i < SIZE; i++) {
    for (int j = 0; j < SIZE; j++) {
      for (int k = 0; k < SIZE; k++) {
        C[i][j] += A[i][k] * B[k][j];
      }
    }
  }
}

/*
 * Performs matrix-matrix multiplication of A and B, storing the
 * result in the matrix C. Assumes C is initiazlied to 0.
 *
 * Same as above except reording the "k" loop to be the outermost loop
 * loop nest.  Convince yourself this is correct
 */
void mmmm_outer(double A[SIZE][SIZE], double B[SIZE][SIZE],
                double C[SIZE][SIZE]) {

  for (int k = 0; k < SIZE; k++) {
    for (int i = 0; i < SIZE; i++) {
      for (int j = 0; j < SIZE; j++) {
        C[i][j] += A[i][k] * B[k][j];
      }
    }
  }
}

int main() {
  struct timeval start_time, end_time;

  for (int i = 0; i < SIZE; i++) {
    for (int j = 0; j < SIZE; j++) {
      A[i][j] = rand();
      B[i][j] = rand();
      C[i][j] = 0.0;
    }
  }

  gettimeofday(&start_time, NULL);
  mmmm(A, B, C);
  gettimeofday(&end_time, NULL);

  double timeusec = (end_time.tv_sec - start_time.tv_sec) * 1e6 +
                    (end_time.tv_usec - start_time.tv_usec);
  printf("runtime: %0.0f usec\n", timeusec);
  printf("size: %d-by-%d\n#ops: %.0f\n", SIZE, SIZE,
         (double)2 * SIZE * SIZE * SIZE);
  printf("throughput: %.2f GigaOP/sec\n\n",
         (double)1.0e-3 * 2 * SIZE * SIZE * SIZE / timeusec);

  {
    int check = 10000; // sample check;

    while (check--) {
      double dot = 0;
      int i = rand() % SIZE;
      int j = rand() % SIZE;
      for (int k = 0; k < SIZE; k++) {
        dot += A[i][k] * B[k][j];
      }
      if (!nearlyEqual(C[i][j], dot)) {
        printf("***** C[%d][%d]=%f, should be %f\n", i, j, C[i][j], dot);
        return 1;
      }
    }
  }
  return 0;
}
