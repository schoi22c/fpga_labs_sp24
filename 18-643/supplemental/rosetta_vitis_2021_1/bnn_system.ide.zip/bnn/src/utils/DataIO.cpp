#include "DataIO.h"
#include <sys/stat.h>

// Relative to the original benchmark release, many things about input
// files became hardcoded here for simplicity sake.  More importantly,
// dependence on minizip to open zipped files is removed to make it
// easier to build and run, especially for Zynq.  No more need for
// ZipIO.cpp/.h, nor minizip/ and aes/.

Cifar10TestInputs::Cifar10TestInputs(unsigned n)
  : m_size(n*CHANNELS*ROWS*COLS)
{
  data = new float[m_size];

  std::string full_filename = filename;
  DB_PRINT(2, "Opening data file %s\n", full_filename.c_str());
  FILE *file = fopen(full_filename.c_str(),"rb");
  struct stat buf;
  int rv=stat(full_filename.c_str(), &buf);

  assert(file);
  assert(!rv);

  // We read m_size*4 bytes from the file
  unsigned fsize = buf.st_size;
  assert(fsize==122880000);
  assert(m_size*4 <= fsize);

  DB_PRINT(2, "Reading %u bytes\n", m_size*4);
  fread((void*)data, sizeof(char), m_size*4, file);
  
  fclose(file);
}

Cifar10TestLabels::Cifar10TestLabels(unsigned n)
  : m_size(n)
{
  data = new float[m_size];

  std::string full_filename = filename;
  DB_PRINT(2, "Opening data file %s\n", full_filename.c_str());
  FILE *file = fopen(full_filename.c_str(),"rb");
  struct stat buf;
  int rv=stat(full_filename.c_str(), &buf);

  assert(file);
  assert(!rv);

  // We read n*4 bytes from the file
  unsigned fsize = buf.st_size;
  assert(fsize==40000);
  assert(m_size*4 <= fsize);

  DB_PRINT(2, "Reading %u bytes\n", m_size*4);
  fread((void*)data, sizeof(char), m_size*4, file);

  fclose(file);
}

