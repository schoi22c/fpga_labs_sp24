#include <assert.h>
#include <sys/stat.h>

#include "ParamIO.h"
#include "Common.h"

// Relative to the original benchmark release, many things about input
// files became hardcoded here for simplicity sake.  More importantly,
// dependence on minizip to open zipped files is removed to make it
// easier to build and run, especially for Zynq.  No more need for
// ZipIO.cpp/.h, nor minizip/ and aes/.

#define NUM_ARR (27)
char *arrfilename[NUM_ARR] = { "params/arr_0", "params/arr_1", "params/arr_2",
		"params/arr_3", "params/arr_4", "params/arr_5", "params/arr_6",
		"params/arr_7", "params/arr_8", "params/arr_9", "params/arr_10",
		"params/arr_11", "params/arr_12", "params/arr_13", "params/arr_14",
		"params/arr_15", "params/arr_16", "params/arr_17", "params/arr_18",
		"params/arr_19", "params/arr_20", "params/arr_21", "params/arr_22",
		"params/arr_23", "params/arr_24", "params/arr_25", "params/arr_26" };
int arrsize[NUM_ARR] = { 13824, 512, 512, 589824, 512, 512, 1179648, 1024, 1024,
		2359296, 1024, 1024, 4718592, 2048, 2048, 9437184, 2048, 2048, 33554432,
		4096, 4096, 4194304, 4096, 4096, 40960, 40, 40 };

Params::Params(std::string zipfile) :
		m_filename(zipfile), m_arrays(0) {
	// Number of param files
	m_arrays = NUM_ARR;
	DB_PRINT(2, "Number of param arrays: %u\n", m_arrays);
	assert(m_arrays <= MAX_LAYERS);

	// Read each array
	for (unsigned i = 0; i < m_arrays; ++i) {
		// Open file
		DB_PRINT(2, "Opening params file %s\n", arrfilename[i]);
		FILE* file = fopen(arrfilename[i], "rb");
		struct stat buf;
		int rv=stat(arrfilename[i], &buf);
		assert(file);
		assert(!rv);

		unsigned fsize = buf.st_size;
		assert(fsize==arrsize[i]);
		m_array_size[i] = fsize;  // size in bytes

		m_data[i] = new float[fsize / 4];

		DB_PRINT(2, "Reading params file size=%d\n", fsize);

		fread((void*) m_data[i], sizeof(char), fsize, file);

		fclose(file);
	}

}

Params::~Params() {
	for (unsigned i = 0; i < m_arrays; ++i)
		delete[] m_data[i];
}

